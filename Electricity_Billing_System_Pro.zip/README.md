# Electricity Billing System Pro

Features
- Generate electricity bills
- Automatic bill calculation based on units consumed
- Payment status tracking
- Total revenue dashboard
- Highest bill tracking
- Responsive glassmorphism UI

Run:
Open index.html in Chrome or Edge.
